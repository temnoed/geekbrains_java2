package ru.geekbrains.java2.dz.dz1;

public class Rook extends Figure {

	boolean isRightMove (Position position, Position destination){

		return true;
	}

}
